public class Swear {

}