public class Animal {
    int age;
    int numLegs;
    boolean canSpeak;

    //Constructors
    public Animal(boolean canSpeak, int numLegs) {
        this.canSpeak = canSpeak;
        this.numLegs = numLegs;
        this.age = 0;
    }

    public Animal(boolean canSpeak, int numLegs, int age) {
        this.canSpeak = canSpeak;
        this.numLegs = numLegs;
        this.age = age;
    }

    //Accessors & Mutators

    public int getAge() {
        return this.age;
    }

    public int getNumLegs() {
        return this.numLegs;
    }

    public boolean getCanSpeak() {
        return canSpeak;
    }

    public void growOlder() {
        this.age++;
    }

    public void growOlder(int years) {
        this.age += age;
    }

//    public void setNumLegs(int numLegs) {
//        this.numLegs = numLegs;
//    }
//
//    public void toggleCanSpeak() {
//        canSpeak = !canSpeak;
//    }
}
