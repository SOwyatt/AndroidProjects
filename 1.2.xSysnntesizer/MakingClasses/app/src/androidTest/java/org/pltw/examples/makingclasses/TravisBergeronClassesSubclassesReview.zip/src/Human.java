public class Human extends Animal {
    String name;
    double money;

    //Constructors
    public Human(String name) {
        super(true, 2);
        this.name = name;
    }

    public Human(int age, String name) {
        super(true, 2, age);
        this.name = name;
    }

    public Human(int age, String name, double money) {
        super(true, 2, age);
        this.name = name;
        this.money = money;
    }

    public Human(String name, double money) {
        super(true, 2);
        this.name = name;
        this.money = money;
    }

    //Accessors

    public String getName() {
        return this.name;
    }

    public double getMoney() {
        return this.money;
    }

    //Mutators

    public void changeName(String newName) {
        this.name = newName;
    }

    public void work(double hours, double wage) {
        this.money += hours * wage;
    }
}
