public class World {
    public static void main(String [] args) {
        Human h1 = new Human("Travis");
        Human h2 = new Human("Travis", 12.4);
        Human h3 = new Human(15, "Travis");
        Human h4 = new Human(15, "Travis", 12.4);

        testHuman(h1);
        testHuman(h2);
        testHuman(h3);
        testHuman(h4);

        //Test all methods
    }

    private static void testHuman(Human h) {
        //Age may not be defined
        try {
            System.out.println("Age: " + h.getAge());

            //growOlder1
            int oldAge = h.getAge();
            h.growOlder();
            if(h.getAge() == oldAge++) System.out.println("GrowOlder1 Works!");

            //GrowOlder2
            oldAge = h.getAge();
            h.growOlder(15);
            if(h.getAge() == oldAge + 15) System.out.println("Growolder2 Works!");
        }
        catch(Exception e) {
            System.out.println("No Age!");
        }

        System.out.println("Name: " + h.getName());
        System.out.println("Money: " + h.getMoney());
        System.out.println("canSpeak: " + h.getCanSpeak());
        System.out.println("numLegs: " + h.getNumLegs());

        //Work
        double oldMoney = h.getMoney();
        h.work(5, 10);
        if(oldMoney + (5*10) == h.getMoney()) System.out.println("Work Works!");

        //changeName
        h.changeName("Not Travis");
        if(h.getName().equals("Not Travis")) System.out.println("ChangeName Works!");

        System.out.println("--------------------");
    }
}
